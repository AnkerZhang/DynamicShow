# Senparc.Weixin.MP.Sample 项目说明

本项目为 .NET Framework 4.5 的 Demo，可以直接编译并发布运行，使用当前项目部署的 Senparc 官方在线 Demo：https://sdk.weixin.senparc.com/。

## .NET Core 及所有版本 Demo

返回上一级后见目录：[Senparc.Weixin.MP.Sample.vs2017](https://github.com/JeffreySu/WeiXinMPSDK/tree/Developer/src/Senparc.Weixin.MP.Sample.vs2017)。


## 其他说明

Senparc.Weixin.MP.Sample.CommonService 里面包含了CustomMessageHandler及原Senparc.Weixin.MP.Sample/Service目录的代码。

分离这些文件是为了在WebForms项目中重用。
