此文件夹用于存放原始的XML通讯记录（请求和响应）。

在Weixin.aspx.cs中进行写入。
