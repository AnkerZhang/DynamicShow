# Senparc.Weixin.MP.Sample.vs2017 项目说明

本项目为 同时支持 .NET 3.5/4.0/4.5/.NET Core 1.1/2.0 的 Demo，可以直接编译并发布运行。

## .NET Framwork 4.5 Demo

返回上一级后见：[Senparc.Weixin.MP.Sample](https://github.com/JeffreySu/WeiXinMPSDK/tree/Developer/src/Senparc.Weixin.MP.Sample)。

使用 .NET Framework 4.5 Sample 部署的 Senparc 官方在线 Demo：https://sdk.weixin.senparc.com/。


## 其他说明

Senparc.Weixin.MP.Sample.CommonService 里面包含了CustomMessageHandler及原Senparc.Weixin.MP.Sample/Service目录的代码。

分离这些文件是为了在WebForms项目中重用。
