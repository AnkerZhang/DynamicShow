## .csproj 文件说明

> Senparc.Weixin.Cache.Redis.csproj：提供给 Senparc.Weixin.MP.Sample.sln 使用的项目文件。<br>
> Senparc.Weixin.Cache.Redis.src.csproj：提供给当前独立项目使用的项目文件。<br>
> Senparc.WebSocket.src.vs2017：提供给 Senparc.Weixin.MP.Sample.vs2017.sln 使用的项目文件。<br>