## .csproj 文件说明

> Senparc.Weixin.MP.MvcExtension.csproj：提供给 Senparc.Weixin.MP.Sample.sln 使用的项目文件。<br>
> Senparc.Weixin.MP.MvcExtension.src.csproj：提供给当前独立项目（Senparc.Weixin.Libraries.sln）使用的项目文件。<br>
> Senparc.Weixin.MP.MvcExtension.src.vs2017：提供给 Senparc.Weixin.MP.Sample.vs2017.sln 使用的项目文件。<br>