﻿using System.Web;
using System.Web.Mvc;

namespace sohovan.com.wxdemo
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}